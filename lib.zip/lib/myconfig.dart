class MyConfig {
  static const String servername = "http://192.168.1.12:8080";
}
